typedef struct Screen TScreen;

typedef struct  Label {
  char          Order;
  TScreen       *OwnerScreen;
  unsigned int  Left;
  unsigned int  Top;
  unsigned int  Width;
  unsigned int  Height;
  char          *Caption;
  const char    *FontName;
  unsigned int  Font_Pos_Ver;
  unsigned int  Font_Color;
  char          Visible;
  char          Active;
  void          (*OnUpPtr)();
  void          (*OnDownPtr)();
  void          (*OnClickPtr)();
  void          (*OnPressPtr)();
} TLabel;

typedef struct  Circle {
  TScreen       *OwnerScreen;
  char          Order;
  unsigned int  Left;
  unsigned int  Top;
  unsigned int  Radius;
  char          Pen_Width;
  unsigned int  Pen_Color;
  char          Visible;
  char          Active;
  char          Transparent;
  char          Gradient;
  char          Gradient_Orientation;
  unsigned int  Gradient_Start_Color;
  unsigned int  Gradient_End_Color;
  unsigned int  Color;
  char          PressColEnabled;
  unsigned int  Press_Color;
  void          (*OnUpPtr)();
  void          (*OnDownPtr)();
  void          (*OnClickPtr)();
  void          (*OnPressPtr)();
} TCircle;

typedef struct  Line {
  TScreen       *OwnerScreen;
  char          Order;
  unsigned int  First_Point_X;
  unsigned int  First_Point_Y;
  unsigned int  Second_Point_X;
  unsigned int  Second_Point_Y;
  char          Pen_Width;
  char          Visible;
  char          Active;
  unsigned int  Color;
} TLine;

struct Screen {
  unsigned int           Color;
  unsigned int           Width;
  unsigned int           Height;
  unsigned short         ObjectsCount;
  unsigned int           LabelsCount;
  TLabel                 **Labels;
  unsigned int           CirclesCount;
  TCircle                **Circles;
  unsigned int           LinesCount;
  TLine                 **Lines;
};

extern   TScreen                Screen1;
extern   TLine                  Line1;
extern   TLine                  Line2;
extern   TLine                  Line3;
extern   TLine                  Line4;
extern   TCircle                Circle1;
extern   TCircle                Circle2;
extern   TCircle                Circle3;
extern   TCircle                Circle4;
extern   TCircle                Circle5;
extern   TLabel                 Label1;



/////////////////////////
// Events Code Declarations
/////////////////////////

/////////////////////////////////
// Caption variables Declarations
extern char Label1_Caption[];
/////////////////////////////////

void DrawScreen(TScreen *aScreen);
void DrawLabel(TLabel *Alabel);
void DrawCircle(TCircle *Acircle);
void DrawLine(TLine *Aline);
void Check_TP();
void Start_TP();
