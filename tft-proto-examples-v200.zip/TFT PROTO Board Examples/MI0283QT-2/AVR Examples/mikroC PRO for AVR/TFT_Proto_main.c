/* Project name:
     TFT_Demo
 * Copyright:
     (c) Mikroelektronika, 2010.
 * Revision History:
     20101224(TL):
       - initial release;
 * Description:
     This is a simple TFT display demo example.
 * Test configuration:
     MCU:             ATmega128
                      http://www.atmel.com/dyn/resources/prod_documents/doc2467.pdf
     Dev.Board:       BIGAVR6
                      http://www.mikroe.com/eng/products/view/322/bigavr6-development-system/
     Oscillator:      HS, 08.0000 MHz
     Ext. Modules:    ac:Voltage_trans
                      http://www.mikroe.com/eng/products/view/182/5v-3-3v-voltage-translator-board/
                      ac:SmartADAPT
                      http://www.mikroe.com/eng/products/view/158/smartadapt2-board/
                      ac:TFT_PROTO
                      http://www.mikroe.com/eng/products/view/474/tft-proto-board/
     SW:              mikroC PRO for AVR
                      http://www.mikroe.com/eng/products/view/228/mikroc-pro-for-avr/
 * NOTES:
     - TFT data and control lines are connected to the system through voltage translators.
       Display is supplied by 3.3V.
       TFT data lines are connected on PORTc, control lines are connected on PORTD.
       IM0 and IM1 are connected to VCC, IM2 and IM3 are on GND.
       DB10 through DB17 are connected to PD0 through PD7
       Other pins are on GND. Vcc is 3.3V !
*/

#include "TFT_Proto_objects.h"

unsigned int x_min, y_min, x_max, y_max;           // Calibration constants
unsigned int x_coord, y_coord;

char x_min_msg[] = "X min:";                       // TFT text messages
char y_min_msg[] = "Y min:";
char x_max_msg[] = "X max:";
char y_max_msg[] = "Y max:";

char x_min_val[6];                                 // Calibration constants string values
char y_min_val[6];
char x_max_val[6];
char y_max_val[6];

void Calibrate() {
  TFT_Set_Pen(CL_WHITE, 3);
  TFT_Circle(314,5,5);
  
  TP_TFT_Calibrate_Min();                  // Calibration of bottom left corner
  Delay_ms(500);

  TFT_Set_Pen(CL_WHITE, 3);                // WHITE
  TFT_Circle(5,234,5);

  TP_TFT_Calibrate_Max();                  // Calibration of upper right corner
  Delay_ms(500);

  TFT_Set_Pen(CL_BLACK, 3);
  Delay_ms(500);

  TP_TFT_Get_Calibration_Consts(&x_min, &x_max, &y_min, &y_max); // Get calibration constants
}

void Display_const(){
  WordToStr(x_min, x_min_val);             // Convert calibration constants into string values
  WordToStr(x_max, x_max_val);
  WordToStr(y_min, y_min_val);
  WordToStr(y_max, y_max_val);

  // Display Calibration constants on TFT

  TFT_Fill_Screen(0);                      // Clear TFT

  TFT_Fill_Screen(CL_WHITE);
  TFT_Write_Text("Constants:", 1, 1);
  TFT_Write_Text(x_min_msg, 5, 15);          // Write messages on TFT
  TFT_Write_Text(x_max_msg, 5, 30);
  TFT_Write_Text(y_min_msg, 5, 45);
  TFT_Write_Text(y_max_msg, 5, 60);

  TFT_Write_Text(x_min_val, 45, 15);         // Write calibration constants values on TFT
  TFT_Write_Text(x_max_val, 45, 30);
  TFT_Write_Text(y_min_val, 45, 45);
  TFT_Write_Text(y_max_val, 45, 60);
}

void main() {

  Start_TP();

  TFT_Fill_Screen(CL_YELLOW);
  Calibrate();

  Display_const();
  while (1) {
    Check_TP();
  }
}