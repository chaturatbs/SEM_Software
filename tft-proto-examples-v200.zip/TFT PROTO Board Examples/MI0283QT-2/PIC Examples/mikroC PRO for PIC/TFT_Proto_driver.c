#include "TFT_Proto_objects.h"
#include "TFT_Proto_resources.h"

// TFT module connections
char TFT_DataPort at LATD;
char TFT_DataPort_Direction at TRISD;
sbit TFT_RST at LATJ0_bit;
sbit TFT_RS at LATJ3_bit;
sbit TFT_CS at LATJ4_bit;
sbit TFT_RD at LATJ1_bit;
sbit TFT_WR at LATJ2_bit;
sbit TFT_RST_Direction at TRISJ0_bit;
sbit TFT_RS_Direction at TRISJ3_bit;
sbit TFT_CS_Direction at TRISJ4_bit;
sbit TFT_RD_Direction at TRISJ1_bit;
sbit TFT_WR_Direction at TRISJ2_bit;
// End Glcd module connections

// Touch Panel module connections
sbit DriveX_Left at LATA0_bit;
sbit DriveX_Right at LATA2_bit;
sbit DriveY_Up at LATA1_bit;
sbit DriveY_Down at LATA3_bit;
sbit DriveX_Left_Direction at TRISA0_bit;
sbit DriveX_Right_Direction at TRISA2_bit;
sbit DriveY_Up_Direction at TRISA1_bit;
sbit DriveY_Down_Direction at TRISA3_bit;
// End Touch Panel module connections

// Global variables
unsigned int Xcoord, Ycoord;
char PenDown;
void *PressedObject;
unsigned int caption_length, caption_height;
unsigned int display_width, display_height;


static void InitializeTouchPanel() {
  ADCON1 = 0xCF;
  ADC_Init();
  TFT_Init(320, 240);

  TP_TFT_Init(320, 240, 0, 1);                                  // Initialize touch panel
  TP_TFT_Set_ADC_Threshold(900);                              // Set touch panel ADC threshold

  PenDown = 0;
  PressedObject = 0;
}


/////////////////////////
  TScreen *CurrentScreen;

  TScreen                Screen1;
  TLine                  Line1;
  TLine                  Line2;
  TLine                  Line3;
  TLine                  Line4;
  TCircle                Circle1;
  TCircle                Circle2;
  TCircle                Circle3;
  TCircle                Circle4;
  TCircle                Circle5;
  TLabel                 Label1;
  char Label1_Caption[36] = "mikroElektronika  TFT  PROTO  board";

  TLabel                 *Screen0_Labels[1];
  TCircle                *Screen0_Circles[5];
  TLine                  *Screen0_Lines[4];




static void InitializeObjects() {
  Screen1.Color                     = 0xC618;
  Screen1.Width                     = 320;
  Screen1.Height                    = 240;
  Screen1.LabelsCount               = 1;
  Screen1.Labels                    = Screen0_Labels;
  Screen1.CirclesCount              = 5;
  Screen1.Circles                   = Screen0_Circles;
  Screen1.LinesCount                = 4;
  Screen1.Lines                     = Screen0_Lines;
  Screen1.ObjectsCount              = 10;
  Screen0_Lines[0]                  = &Line1;
  Screen0_Lines[1]                  = &Line2;
  Screen0_Lines[2]                  = &Line3;
  Screen0_Lines[3]                  = &Line4;
  Screen0_Circles[0]                = &Circle1;
  Screen0_Circles[1]                = &Circle2;
  Screen0_Circles[2]                = &Circle3;
  Screen0_Circles[3]                = &Circle4;
  Screen0_Circles[4]                = &Circle5;
  Screen0_Labels[0]                 = &Label1;


  Line1.OwnerScreen    = &Screen1;
  Line1.Order          = 0;
  Line1.First_Point_X  = 0;
  Line1.First_Point_Y  = 234;
  Line1.Second_Point_X = 324;
  Line1.Second_Point_Y = 234;
  Line1.Pen_Width      = 4;
  Line1.Visible        = 1;
  Line1.Color          = 0x0000;

  Line2.OwnerScreen    = &Screen1;
  Line2.Order          = 1;
  Line2.First_Point_X  = 0;
  Line2.First_Point_Y  = 4;
  Line2.Second_Point_X = 320;
  Line2.Second_Point_Y = 4;
  Line2.Pen_Width      = 4;
  Line2.Visible        = 1;
  Line2.Color          = 0x0000;

  Line3.OwnerScreen    = &Screen1;
  Line3.Order          = 2;
  Line3.First_Point_X  = 315;
  Line3.First_Point_Y  = 4;
  Line3.Second_Point_X = 315;
  Line3.Second_Point_Y = 234;
  Line3.Pen_Width      = 4;
  Line3.Visible        = 1;
  Line3.Color          = 0x0000;

  Line4.OwnerScreen    = &Screen1;
  Line4.Order          = 3;
  Line4.First_Point_X  = 4;
  Line4.First_Point_Y  = 4;
  Line4.Second_Point_X = 4;
  Line4.Second_Point_Y = 234;
  Line4.Pen_Width      = 4;
  Line4.Visible        = 1;
  Line4.Color          = 0x0000;

  Circle1.OwnerScreen     = &Screen1;
  Circle1.Order           = 4;
  Circle1.Left            = 57;
  Circle1.Top             = 10;
  Circle1.Radius          = 100;
  Circle1.Pen_Width       = 1;
  Circle1.Pen_Color       = 0x0000;
  Circle1.Visible         = 1;
  Circle1.Active          = 1;
  Circle1.Transparent     = 1;
  Circle1.Gradient        = 1;
  Circle1.Gradient_Orientation    = 0;
  Circle1.Gradient_Start_Color    = 0xFC08;
  Circle1.Gradient_End_Color      = 0xC618;
  Circle1.Color           = 0xC618;
  Circle1.PressColEnabled = 0;
  Circle1.Press_Color     = 0x8410;
  Circle1.OnUpPtr        = 0;
  Circle1.OnDownPtr      = 0;
  Circle1.OnClickPtr     = 0;
  Circle1.OnPressPtr     = 0;

  Circle2.OwnerScreen     = &Screen1;
  Circle2.Order           = 5;
  Circle2.Left            = 73;
  Circle2.Top             = 26;
  Circle2.Radius          = 83;
  Circle2.Pen_Width       = 1;
  Circle2.Pen_Color       = 0x0000;
  Circle2.Visible         = 1;
  Circle2.Active          = 1;
  Circle2.Transparent     = 1;
  Circle2.Gradient        = 1;
  Circle2.Gradient_Orientation    = 0;
  Circle2.Gradient_Start_Color    = 0xFFE0;
  Circle2.Gradient_End_Color      = 0xC618;
  Circle2.Color           = 0xC618;
  Circle2.PressColEnabled = 0;
  Circle2.Press_Color     = 0x8410;
  Circle2.OnUpPtr        = 0;
  Circle2.OnDownPtr      = 0;
  Circle2.OnClickPtr     = 0;
  Circle2.OnPressPtr     = 0;

  Circle3.OwnerScreen     = &Screen1;
  Circle3.Order           = 6;
  Circle3.Left            = 91;
  Circle3.Top             = 45;
  Circle3.Radius          = 64;
  Circle3.Pen_Width       = 1;
  Circle3.Pen_Color       = 0x0000;
  Circle3.Visible         = 1;
  Circle3.Active          = 1;
  Circle3.Transparent     = 1;
  Circle3.Gradient        = 1;
  Circle3.Gradient_Orientation    = 0;
  Circle3.Gradient_Start_Color    = 0xFFFF;
  Circle3.Gradient_End_Color      = 0xFFF0;
  Circle3.Color           = 0xC618;
  Circle3.PressColEnabled = 0;
  Circle3.Press_Color     = 0x8410;
  Circle3.OnUpPtr        = 0;
  Circle3.OnDownPtr      = 0;
  Circle3.OnClickPtr     = 0;
  Circle3.OnPressPtr     = 0;

  Circle4.OwnerScreen     = &Screen1;
  Circle4.Order           = 7;
  Circle4.Left            = 111;
  Circle4.Top             = 64;
  Circle4.Radius          = 45;
  Circle4.Pen_Width       = 1;
  Circle4.Pen_Color       = 0x0000;
  Circle4.Visible         = 1;
  Circle4.Active          = 1;
  Circle4.Transparent     = 1;
  Circle4.Gradient        = 1;
  Circle4.Gradient_Orientation    = 0;
  Circle4.Gradient_Start_Color    = 0xFFFF;
  Circle4.Gradient_End_Color      = 0x041F;
  Circle4.Color           = 0xC618;
  Circle4.PressColEnabled = 1;
  Circle4.Press_Color     = 0x8410;
  Circle4.OnUpPtr        = 0;
  Circle4.OnDownPtr      = 0;
  Circle4.OnClickPtr     = 0;
  Circle4.OnPressPtr     = 0;

  Circle5.OwnerScreen     = &Screen1;
  Circle5.Order           = 8;
  Circle5.Left            = 129;
  Circle5.Top             = 82;
  Circle5.Radius          = 26;
  Circle5.Pen_Width       = 1;
  Circle5.Pen_Color       = 0x0000;
  Circle5.Visible         = 1;
  Circle5.Active          = 1;
  Circle5.Transparent     = 1;
  Circle5.Gradient        = 1;
  Circle5.Gradient_Orientation    = 0;
  Circle5.Gradient_Start_Color    = 0xFFFF;
  Circle5.Gradient_End_Color      = 0xC618;
  Circle5.Color           = 0xC618;
  Circle5.PressColEnabled = 1;
  Circle5.Press_Color     = 0x8410;
  Circle5.OnUpPtr        = 0;
  Circle5.OnDownPtr      = 0;
  Circle5.OnClickPtr     = 0;
  Circle5.OnPressPtr     = 0;

  Label1.OwnerScreen    = &Screen1;
  Label1.Order          = 9;
  Label1.Left           = 21;
  Label1.Top            = 214;
  Label1.Width          = 274;
  Label1.Height         = 15;
  Label1.Visible        = 1;
  Label1.Active         = 1;
  Label1.Caption        = Label1_Caption;
  Label1.FontName       = Tahoma14x16;
  Label1.Font_Pos_Ver   = 212;
  Label1.Font_Color     = 0xF800;
  Label1.OnUpPtr        = 0;
  Label1.OnDownPtr      = 0;
  Label1.OnClickPtr     = 0;
  Label1.OnPressPtr     = 0;
}

static char IsInsideObject (unsigned int X, unsigned int Y, unsigned int Left, unsigned int Top, unsigned int Width, unsigned int Height) { // static
  if ( (Left<= X) && (Left+ Width - 1 >= X) &&
       (Top <= Y)  && (Top + Height - 1 >= Y) )
    return 1;
  else
    return 0;
}


#define GetLabel(index)               CurrentScreen->Labels[index]
#define GetCircle(index)              CurrentScreen->Circles[index]
#define GetLine(index)                CurrentScreen->Lines[index]


void DrawLabel(TLabel *Alabel) {
  if (Alabel->Visible == 1) {
    TFT_Set_Font(Alabel->FontName, Alabel->Font_Color, FO_HORIZONTAL);
    TFT_Write_Text_Return_Pos(Alabel->Caption, Alabel->Left, Alabel->Top);
    TFT_Write_Text(Alabel->Caption, (Alabel->Left + ((Alabel->Width - caption_length) / 2)),
                  (Alabel->Top + ((Alabel->Height - caption_height) / 2)));
  }
}

static void DrawLabels() {
  int i;
  TLabel *local_label;

  for ( i = 0 ; i < CurrentScreen->LabelsCount ; i++ ) {
    local_label = GetLabel(i);
    DrawLabel(local_label);
  }
}


void DrawCircle(TCircle *Acircle) {
  if (Acircle->Visible == 1) {
    TFT_Set_Brush(Acircle->Transparent, Acircle->Color, Acircle->Gradient, Acircle->Gradient_Orientation,
                  Acircle->Gradient_Start_Color, Acircle->Gradient_End_Color);
    TFT_Set_Pen(Acircle->Pen_Color, Acircle->Pen_Width);
    TFT_Circle(Acircle->Left + Acircle->Radius,
               Acircle->Top + Acircle->Radius,
               Acircle->Radius);
  }
}

static void DrawCircles() {
  int i;
  TCircle *local_circle;

  for ( i = 0 ; i < CurrentScreen->CirclesCount ; i++ ) {
    local_circle = GetCircle(i);
    DrawCircle(local_circle);
  }
}


void DrawLine(TLine *Aline) {
  if (Aline->Visible == 1) {
    TFT_Set_Pen(Aline->Color, Aline->Pen_Width);
    TFT_Line(Aline->First_Point_X, Aline->First_Point_Y, Aline->Second_Point_X, Aline->Second_Point_Y);
  }
}

static void DrawLines() {
  int i;
  TLine *local_line;

  for ( i = 0 ; i < CurrentScreen->LinesCount ; i++ ) {
    local_line = GetLine(i);
    DrawLine(local_line);
  }
}

void DrawScreen(TScreen *aScreen) {
  unsigned short order;
  unsigned short label_idx;
  TLabel *local_label;
  unsigned short circle_idx;
  TCircle *local_circle;
  unsigned short line_idx;
  TLine *local_line;
  order = 0;
  label_idx = 0;
  circle_idx = 0;
  line_idx = 0;

  if ((display_width != aScreen->Width) || (display_height != aScreen->Height)) {
    TFT_Init(aScreen->Width, aScreen->Height);
    TP_TFT_Init(aScreen->Width, aScreen->Height, 0, 1);                                  // Initialize touch panel
    TP_TFT_Set_ADC_Threshold(900);                              // Set touch panel ADC threshold
    TFT_Fill_Screen(aScreen->Color);
    display_width = aScreen->Width;
    display_height = aScreen->Height;
  }
  else
    TFT_Fill_Screen(aScreen->Color);

  CurrentScreen = aScreen;


  while (order < CurrentScreen->ObjectsCount) {
    if (label_idx < CurrentScreen->LabelsCount) {
      local_label = GetLabel(label_idx);
      if (order == local_label->Order) {
        label_idx++;
        order++;
        DrawLabel(local_label);
      }
    }

    if (circle_idx < CurrentScreen->CirclesCount) {
      local_circle = GetCircle(circle_idx);
      if (order == local_circle->Order) {
        circle_idx++;
        order++;
        DrawCircle(local_circle);
      }
    }

    if (line_idx  < CurrentScreen->LinesCount) {
      local_line = GetLine(line_idx);
      if (order == local_line->Order) {
        line_idx++;
        order++;
        DrawLine(local_line);
      }
    }

  }
}

static void Process_TP_Press(unsigned int X, unsigned int Y) {
  int i;
  TLabel *local_label;
  TLabel *exec_label;
  short label_order;
  TCircle *local_circle;
  TCircle *exec_circle;
  short circle_order;

  label_order         = -1;
  circle_order        = -1;

  // Labels
  for ( i = 0 ; i < CurrentScreen->LabelsCount ; i++ ) {
    local_label = GetLabel(i);
    if (local_label->Active == 1) {
      if (IsInsideObject(X, Y, local_label->Left, local_label->Top,
                         local_label->Width, local_label->Height) == 1) {
        label_order = local_label->Order;
        exec_label = local_label;
      }
    }
  }

  // Circles
  for ( i = 0 ; i < CurrentScreen->CirclesCount ; i++ ) {
    local_circle = GetCircle(i);
    if (local_circle->Active == 1) {
      if (IsInsideObject(X, Y, local_circle->Left, local_circle->Top,
                        (local_circle->Radius * 2), (local_circle->Radius * 2)) == 1) {
        circle_order = local_circle->Order;
        exec_circle = local_circle;
      }
    }
  }

  i = -1;
  if (label_order > i)
    i = label_order;
  if (circle_order > i)
    i = circle_order;

  if (i != -1) {
    if (i == label_order) {
      if (exec_label->Active == 1) {
        if (exec_label->OnPressPtr != 0) {
          exec_label->OnPressPtr();
          return;
        }
      }
    }

    if (i == circle_order) {
      if (exec_circle->Active == 1) {
        if (exec_circle->OnPressPtr != 0) {
          exec_circle->OnPressPtr();
          return;
        }
      }
    }

  }
}

static void Process_TP_Up(unsigned int X, unsigned int Y) {
  int i;
  TLabel *local_label;
  TLabel *exec_label;
  short label_order;
  TCircle *local_circle;
  TCircle *exec_circle;
  short circle_order;

  label_order         = -1;
  circle_order        = -1;

  // Labels
  for ( i = 0 ; i < CurrentScreen->LabelsCount ; i++ ) {
    local_label = GetLabel(i);
    if (local_label->Active == 1) {
      if (IsInsideObject(X, Y, local_label->Left, local_label->Top,
                         local_label->Width, local_label->Height) == 1) {
        label_order = local_label->Order;
        exec_label = local_label;
      }
    }
  }

  // Circles
  for ( i = 0 ; i < CurrentScreen->CirclesCount ; i++ ) {
    local_circle = GetCircle(i);
    if (local_circle->Active == 1) {
      if (IsInsideObject(X, Y, local_circle->Left, local_circle->Top,
                        (local_circle->Radius * 2), (local_circle->Radius * 2)) == 1) {
        circle_order = local_circle->Order;
        exec_circle = local_circle;
      }
    }
  }

  i = -1;
  if (label_order > i)
    i = label_order;
  if (circle_order > i)
    i = circle_order;

  if (i != -1) {
  // Labels
    if (i == label_order) {
      if (exec_label->Active == 1) {
        if (exec_label->OnUpPtr != 0)
          exec_label->OnUpPtr();
        if (PressedObject == (void *)exec_label)
          if (exec_label->OnClickPtr != 0)
            exec_label->OnClickPtr();
        PressedObject = 0;
        return;
      }
    }

  // Circles
    if (i == circle_order) {
      if (exec_circle->Active == 1) {
        if ((exec_circle->PressColEnabled == 1) && (PressedObject == (void *)exec_circle)) {
          TFT_Set_Brush(exec_circle->Transparent, exec_circle->Color, exec_circle->Gradient, exec_circle->Gradient_Orientation,
                        exec_circle->Gradient_Start_Color, exec_circle->Gradient_End_Color);
          TFT_Set_Pen(exec_circle->Pen_Color, exec_circle->Pen_Width);
          TFT_Circle(exec_circle->Left + exec_circle->Radius,
                     exec_circle->Top + exec_circle->Radius,
                     exec_circle->Radius);
        }
        if (exec_circle->OnUpPtr != 0)
          exec_circle->OnUpPtr();
        if (PressedObject == (void *)exec_circle)
          if (exec_circle->OnClickPtr != 0)
            exec_circle->OnClickPtr();
        PressedObject = 0;
        return;
      }
    }

  }
  PressedObject = 0;
}

static void Process_TP_Down(unsigned int X, unsigned int Y) {
  int i;
  TLabel *local_label;
  TLabel *exec_label;
  short label_order;
  TCircle *local_circle;
  TCircle *exec_circle;
  short circle_order;

  label_order         = -1;
  circle_order        = -1;

  // Labels
  for ( i = 0 ; i < CurrentScreen->LabelsCount ; i++ ) {
    local_label = GetLabel(i);
    if (local_label->Active == 1) {
      if (IsInsideObject(X, Y, local_label->Left, local_label->Top,
                         local_label->Width, local_label->Height) == 1) {
        label_order = local_label->Order;
        exec_label = local_label;
      }
    }
  }

  // Circles
  for ( i = 0 ; i < CurrentScreen->CirclesCount ; i++ ) {
    local_circle = GetCircle(i);
    if (local_circle->Active == 1) {
      if (IsInsideObject(X, Y, local_circle->Left, local_circle->Top,
                        (local_circle->Radius * 2), (local_circle->Radius * 2)) == 1) {
        circle_order = local_circle->Order;
        exec_circle = local_circle;
      }
    }
  }

  i = -1;
  if (label_order > i)
    i = label_order;
  if (circle_order > i)
    i = circle_order;
  if (i != -1) {
    if (i == label_order) {
      if (exec_label->Active == 1) {
        PressedObject = (void *)exec_label;
        if (exec_label->OnDownPtr != 0) {
          exec_label->OnDownPtr();
          return;
        }
      }
    }

    if (i == circle_order) {
      if (exec_circle->Active == 1) {
        if (exec_circle->PressColEnabled == 1) {
          TFT_Set_Brush(exec_circle->Transparent, exec_circle->Press_Color, exec_circle->Gradient, exec_circle->Gradient_Orientation,
                        exec_circle->Gradient_End_Color, exec_circle->Gradient_Start_Color);
          TFT_Set_Pen(exec_circle->Pen_Color, exec_circle->Pen_Width);
          TFT_Circle(exec_circle->Left + exec_circle->Radius,
                     exec_circle->Top + exec_circle->Radius,
                     exec_circle->Radius);
        }
        PressedObject = (void *)exec_circle;
        if (exec_circle->OnDownPtr != 0) {
          exec_circle->OnDownPtr();
          return;
        }
      }
    }

  }
}

void Check_TP() {
  if (TP_TFT_Press_Detect()) {
    // After a PRESS is detected read X-Y and convert it to Display dimensions space
    if (TP_TFT_Get_Coordinates(&Xcoord, &Ycoord) == 0) {
      Process_TP_Press(Xcoord, Ycoord);
      if (PenDown == 0) {
        PenDown = 1;
        Process_TP_Down(Xcoord, Ycoord);
      }
    }
  }
  else if (PenDown == 1) {
    PenDown = 0;
    Process_TP_Up(Xcoord, Ycoord);
  }
}

void Start_TP() {
  InitializeTouchPanel();

//  ***** You can get calibration constants using touch panel calibration example *****

  InitializeObjects();
  display_width = Screen1.Width;
  display_height = Screen1.Height;
  DrawScreen(&Screen1);
}