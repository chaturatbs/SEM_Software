#include "TFT_demo_objects.h"
#include "TFT_demo_resources.h"

// TFT module connections
char TFT_DataPort at LATE;
char TFT_DataPort_Direction at TRISE;
sbit TFT_RST at LATC1_bit;
sbit TFT_RS at LATB15_bit;
sbit TFT_CS at LATF12_bit;
sbit TFT_RD at LATD5_bit;
sbit TFT_WR at LATD4_bit;
sbit TFT_RST_Direction at TRISC1_bit;
sbit TFT_RS_Direction at TRISB15_bit;
sbit TFT_CS_Direction at TRISF12_bit;
sbit TFT_RD_Direction at TRISD5_bit;
sbit TFT_WR_Direction at TRISD4_bit;
// End Glcd module connections

// Touch Panel module connections
sbit DriveX_Left at LATB13_bit;
sbit DriveX_Right at LATB11_bit;
sbit DriveY_Up at LATB12_bit;
sbit DriveY_Down at LATB10_bit;
sbit DriveX_Left_Direction at TRISB13_bit;
sbit DriveX_Right_Direction at TRISB11_bit;
sbit DriveY_Up_Direction at TRISB12_bit;
sbit DriveY_Down_Direction at TRISB10_bit;
// End Touch Panel module connections

// Global variables
unsigned int Xcoord, Ycoord;
char PenDown;
void *PressedObject;
unsigned int caption_length, caption_height;

static void InitializeTouchPanel() {
  AD1PCFGL = 0xCFFF;
  Delay_ms(150);
  ADC1_Init();
  TFT_Init(320, 240);

  TP_TFT_Init(320, 240, 13, 12);                                  // Initialize touch panel
  TP_TFT_Set_ADC_Threshold(900);                              // Set touch panel ADC threshold

  PenDown = 0;
  PressedObject = 0;
}


/////////////////////////
  TScreen *CurrentScreen;

  TScreen                Screen1;
  TLine                  Line1;
  TLine                  Line2;
  TLine                  Line3;
  TLine                  Line4;
  TLine                  Line5;
  TLine                  Line6;
  TLine                  Line7;
  TLine                  Line8;
  TLine                  Line9;
  TLabel                 Label1;
  char Label1_Caption[10] = "Line Demo";

  TLine                  Line12;
  TLine                  Line13;
  TLine                  Line14;
  TLine                  Line15;
  TLabel                 *Screen0_Labels[1];
  TLine                  *Screen0_Lines[13];

  TScreen                Screen2;
  TBox                   Box1;
  TCircle                Circle1;
  TBox                   Box2;
  TBox_Round             BoxRound1;
  TButton                Button1;
  char Button1_Caption[5] = "Text";

  TButton_Round          ButtonRound1;
  char ButtonRound1_Caption[5] = "Text";

  TCircleButton          CircleButton1;
  char CircleButton1_Caption[5] = "Text";

  TButton                *Screen1_Buttons[1];
  TButton_Round          *Screen1_Buttons_Round[1];
  TCircle                *Screen1_Circles[1];
  TCircleButton          *Screen1_CircleButtons[1];
  TBox                   *Screen1_Boxes[2];
  TBox_Round             *Screen1_Boxes_Round[1];

  TScreen                Screen3;
  TImage                 Image1;
  TImage                 Image2;
  TImage                 *Screen2_Images[2];



static void InitializeObjects() {
  Screen1.Color                     = 0xC77E;
  Screen1.ButtonsCount              = 0;
  Screen1.Buttons_RoundCount        = 0;
  Screen1.LabelsCount               = 1;
  Screen1.Labels                    = Screen0_Labels;
  Screen1.ImagesCount               = 0;
  Screen1.CirclesCount              = 0;
  Screen1.CircleButtonsCount        = 0;
  Screen1.BoxesCount                = 0;
  Screen1.Boxes_RoundCount          = 0;
  Screen1.LinesCount                = 13;
  Screen1.Lines                     = Screen0_Lines;
  Screen1.ObjectsCount              = 14;
  Screen0_Lines[0]                  = &Line1;
  Screen0_Lines[1]                  = &Line2;
  Screen0_Lines[2]                  = &Line3;
  Screen0_Lines[3]                  = &Line4;
  Screen0_Lines[4]                  = &Line5;
  Screen0_Lines[5]                  = &Line6;
  Screen0_Lines[6]                  = &Line7;
  Screen0_Lines[7]                  = &Line8;
  Screen0_Lines[8]                  = &Line9;
  Screen0_Labels[0]                 = &Label1;
  Screen0_Lines[9]                  = &Line12;
  Screen0_Lines[10]                 = &Line13;
  Screen0_Lines[11]                 = &Line14;
  Screen0_Lines[12]                 = &Line15;

  Screen2.Color                     = 0xC77E;
  Screen2.ButtonsCount              = 1;
  Screen2.Buttons                   = Screen1_Buttons;
  Screen2.Buttons_RoundCount        = 1;
  Screen2.Buttons_Round             = Screen1_Buttons_Round;
  Screen2.LabelsCount               = 0;
  Screen2.ImagesCount               = 0;
  Screen2.CirclesCount              = 1;
  Screen2.Circles                   = Screen1_Circles;
  Screen2.CircleButtonsCount        = 1;
  Screen2.CircleButtons             = Screen1_CircleButtons;
  Screen2.BoxesCount                = 2;
  Screen2.Boxes                     = Screen1_Boxes;
  Screen2.Boxes_RoundCount          = 1;
  Screen2.Boxes_Round               = Screen1_Boxes_Round;
  Screen2.LinesCount                = 0;
  Screen2.ObjectsCount              = 7;
  Screen1_Boxes[0]                  = &Box1;
  Screen1_Circles[0]                = &Circle1;
  Screen1_Boxes[1]                  = &Box2;
  Screen1_Boxes_Round[0]            = &BoxRound1;
  Screen1_Buttons[0]                = &Button1;
  Screen1_Buttons_Round[0]          = &ButtonRound1;
  Screen1_CircleButtons[0]          = &CircleButton1;

  Screen3.Color                     = 0xFFFF;
  Screen3.ButtonsCount              = 0;
  Screen3.Buttons_RoundCount        = 0;
  Screen3.LabelsCount               = 0;
  Screen3.ImagesCount               = 2;
  Screen3.Images                    = Screen2_Images;
  Screen3.CirclesCount              = 0;
  Screen3.CircleButtonsCount        = 0;
  Screen3.BoxesCount                = 0;
  Screen3.Boxes_RoundCount          = 0;
  Screen3.LinesCount                = 0;
  Screen3.ObjectsCount              = 2;
  Screen2_Images[0]                 = &Image1;
  Screen2_Images[1]                 = &Image2;


  Line1.OwnerScreen    = &Screen1;
  Line1.Order          = 0;
  Line1.First_Point_X  = 0;
  Line1.First_Point_Y  = 0;
  Line1.Second_Point_X = 319;
  Line1.Second_Point_Y = 239;
  Line1.Pen_Width      = 1;
  Line1.Visible        = 1;
  Line1.Color          = 0x4410;

  Line2.OwnerScreen    = &Screen1;
  Line2.Order          = 1;
  Line2.First_Point_X  = 110;
  Line2.First_Point_Y  = 17;
  Line2.Second_Point_X = 261;
  Line2.Second_Point_Y = 17;
  Line2.Pen_Width      = 1;
  Line2.Visible        = 1;
  Line2.Color          = 0x0000;

  Line3.OwnerScreen    = &Screen1;
  Line3.Order          = 2;
  Line3.First_Point_X  = 261;
  Line3.First_Point_Y  = 17;
  Line3.Second_Point_X = 261;
  Line3.Second_Point_Y = 170;
  Line3.Pen_Width      = 1;
  Line3.Visible        = 1;
  Line3.Color          = 0xFC10;

  Line4.OwnerScreen    = &Screen1;
  Line4.Order          = 3;
  Line4.First_Point_X  = 101;
  Line4.First_Point_Y  = 23;
  Line4.Second_Point_X = 252;
  Line4.Second_Point_Y = 23;
  Line4.Pen_Width      = 2;
  Line4.Visible        = 1;
  Line4.Color          = 0x4010;

  Line5.OwnerScreen    = &Screen1;
  Line5.Order          = 4;
  Line5.First_Point_X  = 252;
  Line5.First_Point_Y  = 23;
  Line5.Second_Point_X = 252;
  Line5.Second_Point_Y = 176;
  Line5.Pen_Width      = 2;
  Line5.Visible        = 1;
  Line5.Color          = 0xFFF0;

  Line6.OwnerScreen    = &Screen1;
  Line6.Order          = 5;
  Line6.First_Point_X  = 89;
  Line6.First_Point_Y  = 33;
  Line6.Second_Point_X = 240;
  Line6.Second_Point_Y = 33;
  Line6.Pen_Width      = 3;
  Line6.Visible        = 1;
  Line6.Color          = 0x801F;

  Line7.OwnerScreen    = &Screen1;
  Line7.Order          = 6;
  Line7.First_Point_X  = 240;
  Line7.First_Point_Y  = 33;
  Line7.Second_Point_X = 240;
  Line7.Second_Point_Y = 186;
  Line7.Pen_Width      = 3;
  Line7.Visible        = 1;
  Line7.Color          = 0x07F0;

  Line8.OwnerScreen    = &Screen1;
  Line8.Order          = 7;
  Line8.First_Point_X  = 74;
  Line8.First_Point_Y  = 47;
  Line8.Second_Point_X = 225;
  Line8.Second_Point_Y = 47;
  Line8.Pen_Width      = 4;
  Line8.Visible        = 1;
  Line8.Color          = 0xF810;

  Line9.OwnerScreen    = &Screen1;
  Line9.Order          = 8;
  Line9.First_Point_X  = 225;
  Line9.First_Point_Y  = 47;
  Line9.Second_Point_X = 225;
  Line9.Second_Point_Y = 200;
  Line9.Pen_Width      = 4;
  Line9.Visible        = 1;
  Line9.Color          = 0x8000;

  Label1.OwnerScreen    = &Screen1;
  Label1.Order          = 9;
  Label1.Left           = 39;
  Label1.Top            = 152;
  Label1.Width          = 88;
  Label1.Height         = 18;
  Label1.Visible        = 1;
  Label1.Active         = 1;
  Label1.Caption        = Label1_Caption;
  Label1.FontName       = Tahoma16x19;
  Label1.Font_Pos_Ver   = 150;
  Label1.Font_Color     = 0x0400;
  Label1.OnUpPtr        = 0;
  Label1.OnDownPtr      = 0;
  Label1.OnClickPtr     = 0;
  Label1.OnPressPtr     = 0;

  Line12.OwnerScreen    = &Screen1;
  Line12.Order          = 10;
  Line12.First_Point_X  = 10;
  Line12.First_Point_Y  = 170;
  Line12.Second_Point_X = 86;
  Line12.Second_Point_Y = 108;
  Line12.Pen_Width      = 4;
  Line12.Visible        = 1;
  Line12.Color          = 0x05D3;

  Line13.OwnerScreen    = &Screen1;
  Line13.Order          = 11;
  Line13.First_Point_X  = 86;
  Line13.First_Point_Y  = 108;
  Line13.Second_Point_X = 156;
  Line13.Second_Point_Y = 175;
  Line13.Pen_Width      = 1;
  Line13.Visible        = 1;
  Line13.Color          = 0xBAC0;

  Line14.OwnerScreen    = &Screen1;
  Line14.Order          = 12;
  Line14.First_Point_X  = 86;
  Line14.First_Point_Y  = 214;
  Line14.Second_Point_X = 156;
  Line14.Second_Point_Y = 175;
  Line14.Pen_Width      = 2;
  Line14.Visible        = 1;
  Line14.Color          = 0xBD60;

  Line15.OwnerScreen    = &Screen1;
  Line15.Order          = 13;
  Line15.First_Point_X  = 86;
  Line15.First_Point_Y  = 214;
  Line15.Second_Point_X = 10;
  Line15.Second_Point_Y = 170;
  Line15.Pen_Width      = 3;
  Line15.Visible        = 1;
  Line15.Color          = 0x65C0;

  Box1.OwnerScreen     = &Screen2;
  Box1.Order           = 0;
  Box1.Left            = 29;
  Box1.Top             = 46;
  Box1.Width           = 255;
  Box1.Height          = 144;
  Box1.Pen_Width       = 2;
  Box1.Pen_Color       = 0xF800;
  Box1.Visible         = 1;
  Box1.Active          = 1;
  Box1.Transparent     = 1;
  Box1.Gradient        = 0;
  Box1.Gradient_Orientation    = 0;
  Box1.Gradient_Start_Color    = 0xFFFF;
  Box1.Gradient_End_Color      = 0xC618;
  Box1.Color           = 0x2DD9;
  Box1.PressColEnabled = 1;
  Box1.Press_Color     = 0x8410;
  Box1.OnUpPtr        = 0;
  Box1.OnDownPtr      = 0;
  Box1.OnClickPtr     = 0;
  Box1.OnPressPtr     = 0;
  Circle1.OwnerScreen     = &Screen2;
  Circle1.Order           = 1;
  Circle1.Left            = 80;
  Circle1.Top             = 59;
  Circle1.Radius          = 18;
  Circle1.Pen_Width       = 1;
  Circle1.Pen_Color       = 0x0000;
  Circle1.Visible         = 1;
  Circle1.Active          = 1;
  Circle1.Transparent     = 1;
  Circle1.Gradient        = 1;
  Circle1.Gradient_Orientation    = 0;
  Circle1.Gradient_Start_Color    = 0xFC10;
  Circle1.Gradient_End_Color      = 0x001F;
  Circle1.Color           = 0xC618;
  Circle1.PressColEnabled = 1;
  Circle1.Press_Color     = 0x8410;
  Circle1.OnUpPtr        = 0;
  Circle1.OnDownPtr      = 0;
  Circle1.OnClickPtr     = 0;
  Circle1.OnPressPtr     = 0;

  Box2.OwnerScreen     = &Screen2;
  Box2.Order           = 2;
  Box2.Left            = 74;
  Box2.Top             = 100;
  Box2.Width           = 50;
  Box2.Height          = 25;
  Box2.Pen_Width       = 1;
  Box2.Pen_Color       = 0x0000;
  Box2.Visible         = 1;
  Box2.Active          = 1;
  Box2.Transparent     = 1;
  Box2.Gradient        = 1;
  Box2.Gradient_Orientation    = 0;
  Box2.Gradient_Start_Color    = 0x001F;
  Box2.Gradient_End_Color      = 0xC618;
  Box2.Color           = 0xC618;
  Box2.PressColEnabled = 1;
  Box2.Press_Color     = 0x8410;
  Box2.OnUpPtr        = 0;
  Box2.OnDownPtr      = 0;
  Box2.OnClickPtr     = 0;
  Box2.OnPressPtr     = 0;

  BoxRound1.OwnerScreen     = &Screen2;
  BoxRound1.Order           = 3;
  BoxRound1.Left            = 74;
  BoxRound1.Top             = 139;
  BoxRound1.Width           = 50;
  BoxRound1.Height          = 25;
  BoxRound1.Pen_Width       = 1;
  BoxRound1.Pen_Color       = 0x0000;
  BoxRound1.Visible         = 1;
  BoxRound1.Active          = 1;
  BoxRound1.Transparent     = 1;
  BoxRound1.Gradient        = 1;
  BoxRound1.Gradient_Orientation    = 0;
  BoxRound1.Gradient_Start_Color    = 0x001F;
  BoxRound1.Gradient_End_Color      = 0xF800;
  BoxRound1.Color           = 0x8410;
  BoxRound1.PressColEnabled = 1;
  BoxRound1.Press_Color     = 0x8410;
  BoxRound1.OnUpPtr        = 0;
  BoxRound1.OnDownPtr      = 0;
  BoxRound1.OnClickPtr     = 0;
  BoxRound1.OnPressPtr     = 0;

  Button1.OwnerScreen     = &Screen2;
  Button1.Order           = 4;
  Button1.Left            = 178;
  Button1.Top             = 59;
  Button1.Width           = 50;
  Button1.Height          = 25;
  Button1.Pen_Width       = 1;
  Button1.Pen_Color       = 0x0000;
  Button1.Visible         = 1;
  Button1.Active          = 1;
  Button1.Transparent     = 1;
  Button1.Caption         = Button1_Caption;
  Button1.FontName        = Tahoma11x13;
  Button1.Font_Color      = 0x0400;
  Button1.Gradient        = 1;
  Button1.Gradient_Orientation    = 0;
  Button1.Gradient_Start_Color    = 0xFFFF;
  Button1.Gradient_End_Color      = 0xC618;
  Button1.Color           = 0xC618;
  Button1.PressColEnabled = 1;
  Button1.Press_Color     = 0xC618;
  Button1.OnUpPtr        = 0;
  Button1.OnDownPtr      = 0;
  Button1.OnClickPtr     = 0;
  Button1.OnPressPtr     = 0;

  ButtonRound1.OwnerScreen     = &Screen2;
  ButtonRound1.Order           = 5;
  ButtonRound1.Left            = 175;
  ButtonRound1.Top             = 100;
  ButtonRound1.Width           = 56;
  ButtonRound1.Height          = 31;
  ButtonRound1.Pen_Width       = 1;
  ButtonRound1.Pen_Color       = 0x0000;
  ButtonRound1.Visible         = 1;
  ButtonRound1.Active          = 1;
  ButtonRound1.Transparent     = 1;
  ButtonRound1.Caption         = ButtonRound1_Caption;
  ButtonRound1.FontName        = Tahoma11x13;
  ButtonRound1.Font_Color      = 0xF800;
  ButtonRound1.Gradient        = 1;
  ButtonRound1.Gradient_Orientation    = 0;
  ButtonRound1.Gradient_Start_Color    = 0xFFFF;
  ButtonRound1.Gradient_End_Color      = 0xC618;
  ButtonRound1.Color           = 0xC618;
  ButtonRound1.PressColEnabled = 1;
  ButtonRound1.Press_Color     = 0x8410;
  ButtonRound1.OnUpPtr        = 0;
  ButtonRound1.OnDownPtr      = 0;
  ButtonRound1.OnClickPtr     = 0;
  ButtonRound1.OnPressPtr     = 0;

  CircleButton1.OwnerScreen    = &Screen2;
  CircleButton1.Order          = 6;
  CircleButton1.Left           = 184;
  CircleButton1.Top            = 139;
  CircleButton1.Radius         = 18;
  CircleButton1.Pen_Width      = 1;
  CircleButton1.Pen_Color      = 0x0000;
  CircleButton1.Visible        = 1;
  CircleButton1.Active         = 1;
  CircleButton1.Transparent    = 1;
  CircleButton1.Caption        = CircleButton1_Caption;
  CircleButton1.FontName       = Tahoma11x13;
  CircleButton1.Font_Color     = 0x0000;
  CircleButton1.Gradient       = 1;
  CircleButton1.Gradient_Orientation    = 0;
  CircleButton1.Gradient_Start_Color    = 0xFFFF;
  CircleButton1.Gradient_End_Color      = 0xC618;
  CircleButton1.Color          = 0xC618;
  CircleButton1.PressColEnabled = 1;
  CircleButton1.Press_Color    = 0x8410;
  CircleButton1.OnUpPtr        = 0;
  CircleButton1.OnDownPtr      = 0;
  CircleButton1.OnClickPtr     = 0;
  CircleButton1.OnPressPtr     = 0;

  Image1.OwnerScreen    = &Screen3;
  Image1.Order          = 0;
  Image1.Left           = 76;
  Image1.Top            = 45;
  Image1.Width          = 150;
  Image1.Height         = 24;
  Image1.Picture_Type   = 0;
  Image1.Picture_Ratio  = 1;
  Image1.Picture_Name   = Image1_logo;
  Image1.Visible        = 1;
  Image1.Active         = 1;
  Image1.OnUpPtr        = 0;
  Image1.OnDownPtr      = 0;
  Image1.OnClickPtr     = 0;
  Image1.OnPressPtr     = 0;

  Image2.OwnerScreen    = &Screen3;
  Image2.Order          = 1;
  Image2.Left           = 53;
  Image2.Top            = 120;
  Image2.Width          = 200;
  Image2.Height         = 32;
  Image2.Picture_Type   = 1;
  Image2.Picture_Name   = Image2_logo;
  Image2.Visible        = 1;
  Image2.Active         = 1;
  Image2.OnUpPtr        = 0;
  Image2.OnDownPtr      = 0;
  Image2.OnClickPtr     = 0;
  Image2.OnPressPtr     = 0;
}

static char IsInsideObject (unsigned int X, unsigned int Y, unsigned int Left, unsigned int Top, unsigned int Width, unsigned int Height) { // static
  if ( (Left<= X) && (Left+ Width - 1 >= X) &&
       (Top <= Y)  && (Top + Height - 1 >= Y) )
    return 1;
  else
    return 0;
}

#define GetButton(index)              CurrentScreen->Buttons[index]
#define GetRoundButton(index)         CurrentScreen->Buttons_Round[index]
#define GetLabel(index)               CurrentScreen->Labels[index]
#define GetImage(index)               CurrentScreen->Images[index]
#define GetCircle(index)              CurrentScreen->Circles[index]
#define GetCircleButton(index)        CurrentScreen->CircleButtons[index]
#define GetBox(index)                 CurrentScreen->Boxes[index]
#define GetBox_Round(index)           CurrentScreen->Boxes_Round[index]
#define GetLine(index)                CurrentScreen->Lines[index]


void DrawButton(TButton *Abutton) {
  if (Abutton->Visible == 1) {
    TFT_Set_Brush(Abutton->Transparent, Abutton->Color, Abutton->Gradient, Abutton->Gradient_Orientation, Abutton->Gradient_Start_Color, Abutton->Gradient_End_Color);
    TFT_Set_Pen(Abutton->Pen_Color, Abutton->Pen_Width);
    TFT_Rectangle(Abutton->Left, Abutton->Top, Abutton->Left + Abutton->Width - 1, Abutton->Top + Abutton->Height - 1);
    TFT_Set_Font(Abutton->FontName, Abutton->Font_Color, FO_HORIZONTAL);
    TFT_Write_Text_Return_Pos(Abutton->Caption, Abutton->Left, Abutton->Top);
    TFT_Write_Text(Abutton->Caption, (Abutton->Left + ((Abutton->Width - caption_length) / 2)), (Abutton->Top + ((Abutton->Height - caption_height) / 2)));
  }
}

static void DrawButtons() {
  int i;
  TButton *local_button;

  for ( i = 0 ; i < CurrentScreen->ButtonsCount ; i++ ) {
    local_button = GetButton(i);
    DrawButton(local_button);
  }
}


void DrawRoundButton(TButton_Round *Around_button) {
    if (Around_button->Visible == 1) {
      TFT_Set_Brush(Around_button->Transparent, Around_button->Color, Around_button->Gradient, Around_button->Gradient_Orientation,
                    Around_button->Gradient_Start_Color, Around_button->Gradient_End_Color);
      TFT_Set_Pen(Around_button->Pen_Color, Around_button->Pen_Width);
      if (Around_button->Height > Around_button->Width) {
        TFT_Rectangle_Round_Edges(Around_button->Left + 1, Around_button->Top + 1,
          Around_button->Left + Around_button->Width - 2,
          Around_button->Top + Around_button->Height - 2, (Around_button->Width/4));
      }
      else
        if (Around_button->Width > Around_button->Height) {
          TFT_Rectangle_Round_Edges(Around_button->Left + 1, Around_button->Top + 1,
            Around_button->Left + Around_button->Width - 2,
            Around_button->Top + Around_button->Height - 2, (Around_button->Height/4));
        }
      TFT_Set_Font(Around_button->FontName, Around_button->Font_Color, FO_HORIZONTAL);
      TFT_Write_Text_Return_Pos(Around_button->Caption, Around_button->Left, Around_button->Top);
      TFT_Write_Text(Around_button->Caption, (Around_button->Left + ((Around_button->Width - caption_length) / 2)),
                    (Around_button->Top + ((Around_button->Height - caption_height) / 2)));
    }
}

static void DrawRoundButtons() {
  int i;
  TButton_Round *local_round_button;

  for ( i = 0 ; i < CurrentScreen->Buttons_RoundCount ; i++ ) {
    local_round_button = GetRoundButton(i);
    DrawRoundButton(local_round_button);
  }
}


void DrawLabel(TLabel *Alabel) {
  if (Alabel->Visible == 1) {
    TFT_Set_Font(Alabel->FontName, Alabel->Font_Color, FO_HORIZONTAL);
    TFT_Write_Text_Return_Pos(Alabel->Caption, Alabel->Left, Alabel->Top);
    TFT_Write_Text(Alabel->Caption, (Alabel->Left + ((Alabel->Width - caption_length) / 2)),
                  (Alabel->Top + ((Alabel->Height - caption_height) / 2)));
  }
}

static void DrawLabels() {
  int i;
  TLabel *local_label;

  for ( i = 0 ; i < CurrentScreen->LabelsCount ; i++ ) {
    local_label = GetLabel(i);
    DrawLabel(local_label);
  }
}


void DrawImage(TImage *Aimage) {
  if (Aimage->Visible == 1) {
    if (Aimage->Picture_Type == 0) {
      TFT_Image(Aimage->Left, Aimage->Top, Aimage->Picture_Name, Aimage->Picture_Ratio);
    }
    if (Aimage->Picture_Type == 1) {
      TFT_Image_Jpeg(Aimage->Left, Aimage->Top, Aimage->Picture_Name);
    }
  }
}

static void DrawImages() {
  int i;
  TImage *local_image;

  for ( i = 0 ; i < CurrentScreen->ImagesCount ; i++ ) {
    local_image = GetImage(i);
    DrawImage(local_image);
  }
}


static void DrawCircle(TCircle *Acircle) {
  if (Acircle->Visible == 1) {
    TFT_Set_Brush(Acircle->Transparent, Acircle->Color, Acircle->Gradient, Acircle->Gradient_Orientation,
                  Acircle->Gradient_Start_Color, Acircle->Gradient_End_Color);
    TFT_Set_Pen(Acircle->Pen_Color, Acircle->Pen_Width);
    TFT_Circle(Acircle->Left + Acircle->Radius,
               Acircle->Top + Acircle->Radius,
               Acircle->Radius);
  }
}

static void DrawCircles() {
  int i;
  TCircle *local_circle;

  for ( i = 0 ; i < CurrentScreen->CirclesCount ; i++ ) {
    local_circle = GetCircle(i);
    DrawCircle(local_circle);
  }
}


static void DrawCircleButton(TCircleButton *Acircle_button) {
  if (Acircle_button->Visible == 1) {
    TFT_Set_Brush(Acircle_button->Transparent, Acircle_button->Color, Acircle_button->Gradient, Acircle_button->Gradient_Orientation,
                  Acircle_button->Gradient_Start_Color, Acircle_button->Gradient_End_Color);
    TFT_Set_Pen(Acircle_button->Pen_Color, Acircle_button->Pen_Width);
    TFT_Circle(Acircle_button->Left + Acircle_button->Radius,
               Acircle_button->Top + Acircle_button->Radius,
               Acircle_button->Radius);
    TFT_Set_Font(Acircle_button->FontName, Acircle_button->Font_Color, FO_HORIZONTAL);
    TFT_Write_Text_Return_Pos(Acircle_button->Caption, Acircle_button->Left, Acircle_button->Top);
    TFT_Write_Text(Acircle_button->Caption, (Acircle_button->Left + (((Acircle_button->Radius*2) - caption_length) / 2)),
                  (Acircle_button->Top + (((Acircle_button->Radius*2) - caption_height) / 2)));
  }
}

static void DrawCircleButtons() {
  int i;
  TCircleButton *local_circle_button;

  for ( i = 0 ; i < CurrentScreen->CircleButtonsCount ; i++ ) {
    local_circle_button = GetCircleButton(i);
    DrawCircleButton(local_circle_button);
  }
}


void DrawBox(TBox *ABox) {
  if (ABox->Visible == 1) {
    TFT_Set_Brush(ABox->Transparent, ABox->Color, ABox->Gradient, ABox->Gradient_Orientation, ABox->Gradient_Start_Color, ABox->Gradient_End_Color);
    TFT_Set_Pen(ABox->Pen_Color, ABox->Pen_Width);
    TFT_Rectangle(ABox->Left, ABox->Top, ABox->Left + ABox->Width - 1, ABox->Top + ABox->Height - 1);
  }
}

static void DrawBoxes() {
  int i;
  TBox *local_box;

  for ( i = 0 ; i < CurrentScreen->BoxesCount ; i++ ) {
    local_box = GetBox(i);
    DrawBox(local_box);
  }
}


void DrawRoundBox(TBox_Round *Around_box) {
    if (Around_box->Visible == 1) {
      TFT_Set_Brush(Around_box->Transparent, Around_box->Color, Around_box->Gradient, Around_box->Gradient_Orientation,
                    Around_box->Gradient_Start_Color, Around_box->Gradient_End_Color);
      TFT_Set_Pen(Around_box->Pen_Color, Around_box->Pen_Width);
      if (Around_box->Height > Around_box->Width) {
        TFT_Rectangle_Round_Edges(Around_box->Left + 1, Around_box->Top + 1,
          Around_box->Left + Around_box->Width - 2,
          Around_box->Top + Around_box->Height - 2, (Around_box->Width/4));
      }
      else
        if (Around_box->Width > Around_box->Height) {
          TFT_Rectangle_Round_Edges(Around_box->Left + 1, Around_box->Top + 1,
            Around_box->Left + Around_box->Width - 2,
            Around_box->Top + Around_box->Height - 2, (Around_box->Height/4));
        }
    }
}

static void DrawRoundBoxes() {
  int i;
  TBox_Round *local_round_box;

  for ( i = 0 ; i < CurrentScreen->Boxes_RoundCount ; i++ ) {
    local_round_box = GetBox_Round(i);
    DrawRoundBox(local_round_box);
  }
}


void DrawLine(TLine *Aline) {
  if (Aline->Visible == 1) {
    TFT_Set_Pen(Aline->Color, Aline->Pen_Width);
    TFT_Line(Aline->First_Point_X, Aline->First_Point_Y, Aline->Second_Point_X, Aline->Second_Point_Y);
  }
}

static void DrawLines() {
  int i;
  TLine *local_line;

  for ( i = 0 ; i < CurrentScreen->LinesCount ; i++ ) {
    local_line = GetLine(i);
    DrawLine(local_line);
  }
}

void DrawScreen(TScreen *aScreen) {
  unsigned short order;
  unsigned short button_idx;
  TButton *local_button;
  unsigned short round_button_idx;
  TButton_Round *local_round_button;
  unsigned short label_idx;
  TLabel *local_label;
  unsigned short image_idx;
  TImage *local_image;
  unsigned short circle_idx;
  TCircle *local_circle;
  unsigned short circle_button_idx;
  TCircleButton *local_circle_button;
  unsigned short box_idx;
  TBox *local_box;
  unsigned short round_box_idx;
  TBox_Round *local_round_box;
  unsigned short line_idx;
  TLine *local_line;
  order = 0;
  button_idx = 0;
  round_button_idx = 0;
  label_idx = 0;
  image_idx = 0;
  circle_idx = 0;
  circle_button_idx = 0;
  box_idx = 0;
  round_box_idx = 0;
  line_idx = 0;
  TFT_Fill_Screen(aScreen->Color);
  CurrentScreen = aScreen;


  while (order < CurrentScreen->ObjectsCount) {
    if (button_idx < CurrentScreen->ButtonsCount) {
      local_button = GetButton(button_idx);
      if (order == local_button->Order) {
        button_idx++;
        order++;
        DrawButton(local_button);
      }
    }

    if (round_button_idx < CurrentScreen->Buttons_RoundCount) {
      local_round_button = GetRoundButton(round_button_idx);
      if (order == local_round_button->Order) {
        order++;
        round_button_idx++;
        DrawRoundButton(local_round_button);
      }
    }

    if (label_idx < CurrentScreen->LabelsCount) {
      local_label = GetLabel(label_idx);
      if (order == local_label->Order) {
        label_idx++;
        order++;
        DrawLabel(local_label);
      }
    }

    if (circle_idx < CurrentScreen->CirclesCount) {
      local_circle = GetCircle(circle_idx);
      if (order == local_circle->Order) {
        circle_idx++;
        order++;
        DrawCircle(local_circle);
      }
    }

    if (circle_button_idx < CurrentScreen->CircleButtonsCount) {
      local_circle_button = GetCircleButton(circle_button_idx);
      if (order == local_circle_button->Order) {
        circle_button_idx++;
        order++;
        DrawCircleButton(local_circle_button);
      }
    }

    if (box_idx < CurrentScreen->BoxesCount) {
      local_box = GetBox(box_idx);
      if (order == local_box->Order) {
        box_idx++;
        order++;
        DrawBox(local_box);
      }
    }

    if (round_box_idx < CurrentScreen->Boxes_RoundCount) {
      local_round_box = GetBox_Round(round_box_idx);
      if (order == local_round_box->Order) {
        round_box_idx++;
        order++;
        DrawRoundBox(local_round_box);
      }
    }

    if (line_idx  < CurrentScreen->LinesCount) {
      local_line = GetLine(line_idx);
      if (order == local_line->Order) {
        line_idx++;
        order++;
        DrawLine(local_line);
      }
    }

    if (image_idx  < CurrentScreen->ImagesCount) {
      local_image = GetImage(image_idx);
      if (order == local_image->Order) {
        image_idx++;
        order++;
        DrawImage(local_image);
      }
    }

  }
}

static void Process_TP_Press(unsigned int X, unsigned int Y) {
  int i;
  TButton *local_button;
  TButton *exec_button;
  short button_order;
  TButton_Round *local_round_button;
  TButton_Round *exec_round_button;
  short round_button_order;
  TLabel *local_label;
  TLabel *exec_label;
  short label_order;
  TImage *local_image;
  TImage *exec_image;
  short image_order;
  TCircle *local_circle;
  TCircle *exec_circle;
  short circle_order;
  TCircleButton *local_circle_button;
  TCircleButton *exec_circle_button;
  short circle_button_order;
  TBox *local_box;
  TBox *exec_box;
  short box_order;
  TBox_Round *local_round_box;
  TBox_Round *exec_round_box;
  short box_round_order;

  button_order        = -1;
  round_button_order  = -1;
  label_order         = -1;
  image_order         = -1;
  circle_order        = -1;
  circle_button_order = -1;
  box_order           = -1;
  box_round_order     = -1;

  // Buttons
  for ( i = 0 ; i < CurrentScreen->ButtonsCount ; i++ ) {
    local_button = GetButton(i);
    if (local_button->Active == 1) {
      if (IsInsideObject(X, Y, local_button->Left, local_button->Top,
                         local_button->Width, local_button->Height) == 1) {
        button_order = local_button->Order;
        exec_button = local_button;
      }
    }
  }

  // Buttons with Round Edges
  for ( i = 0 ; i < CurrentScreen->Buttons_RoundCount ; i++ ) {
    local_round_button = GetRoundButton(i);
    if (local_round_button->Active == 1) {
      if (IsInsideObject(X, Y, local_round_button->Left, local_round_button->Top,
                         local_round_button->Width, local_round_button->Height) == 1) { +
        round_button_order = local_round_button->Order;
        exec_round_button = local_round_button;
      }
    }
  }

  // Labels
  for ( i = 0 ; i < CurrentScreen->LabelsCount ; i++ ) {
    local_label = GetLabel(i);
    if (local_label->Active == 1) {
      if (IsInsideObject(X, Y, local_label->Left, local_label->Top,
                         local_label->Width, local_label->Height) == 1) { +
        label_order = local_label->Order;
        exec_label = local_label;
      }
    }
  }

  // Images
  for ( i = 0 ; i < CurrentScreen->ImagesCount ; i++ ) {
    local_image = GetImage(i);
    if (local_image->Active == 1) {
      if (IsInsideObject(X, Y, local_image->Left, local_image->Top,
                         local_image->Width, local_image->Height) == 1) { +
        image_order = local_image->Order;
        exec_image = local_image;
      }
    }
  }

  // Circles
  for ( i = 0 ; i < CurrentScreen->CirclesCount ; i++ ) {
    local_circle = GetCircle(i);
    if (local_circle->Active == 1) {
      if (IsInsideObject(X, Y, local_circle->Left, local_circle->Top,
                        (local_circle->Radius * 2), (local_circle->Radius * 2)) == 1) { +
        circle_order = local_circle->Order;
        exec_circle = local_circle;
      }
    }
  }

  // Circle Buttons
  for ( i = 0 ; i < CurrentScreen->CircleButtonsCount ; i++ ) {
    local_circle_button = GetCircleButton(i);
    if (local_circle_button->Active == 1) {
      if (IsInsideObject(X, Y, local_circle_button->Left, local_circle_button->Top,
                        (local_circle_button->Radius * 2), (local_circle_button->Radius * 2)) == 1) { +
        circle_button_order = local_circle_button->Order;
        exec_circle_button = local_circle_button;
      }
    }
  }

  // Boxes
  for ( i = 0 ; i < CurrentScreen->BoxesCount ; i++ ) {
    local_box = GetBox(i);
    if (local_box->Active == 1) {
      if (IsInsideObject(X, Y, local_box->Left, local_box->Top,
                         local_box->Width, local_box->Height) == 1) { +
        box_order = local_box->Order;
        exec_box = local_box;
      }
    }
  }

  // Boxes with Round Edges
  for ( i = 0 ; i < CurrentScreen->Boxes_RoundCount ; i++ ) {
    local_round_box = GetBox_Round(i);
    if (local_round_box->Active == 1) {
      if (IsInsideObject(X, Y, local_round_box->Left, local_round_box->Top,
                         local_round_box->Width, local_round_box->Height) == 1) { +
        box_round_order = local_round_box->Order;
        exec_round_box = local_round_box;
      }
    }
  }

  i = -1;
  if (button_order > i)
    i = button_order;
  if (round_button_order > i)
    i = round_button_order;
  if (label_order > i)
    i = label_order;
  if (image_order > i)
    i = image_order;
  if (circle_order > i)
    i = circle_order;
  if (circle_button_order > i)
    i = circle_button_order;
  if (box_order > i)
    i = box_order;
  if (box_round_order > i)
    i = box_round_order;

  if (i != -1) {
    if (i == button_order) {
      if (exec_button->Active == 1) {
        if (exec_button->OnPressPtr != 0) {
          exec_button->OnPressPtr();
          return;
        }
      }
    }

    if (i == round_button_order) {
      if (exec_round_button->Active == 1) {
        if (exec_round_button->OnPressPtr != 0) {
          exec_round_button->OnPressPtr();
          return;
        }
      }
    }

    if (i == label_order) {
      if (exec_label->Active == 1) {
        if (exec_label->OnPressPtr != 0) {
          exec_label->OnPressPtr();
          return;
        }
      }
    }

    if (i == image_order) {
      if (exec_image->Active == 1) {
        if (exec_image->OnPressPtr != 0) {
          exec_image->OnPressPtr();
          return;
        }
      }
    }

    if (i == circle_order) {
      if (exec_circle->Active == 1) {
        if (exec_circle->OnPressPtr != 0) {
          exec_circle->OnPressPtr();
          return;
        }
      }
    }

    if (i == circle_button_order) {
      if (exec_circle_button->Active == 1) {
        if (exec_circle_button->OnPressPtr != 0) {
          exec_circle_button->OnPressPtr();
          return;
        }
      }
    }

    if (i == box_order) {
      if (exec_box->Active == 1) {
        if (exec_box->OnPressPtr != 0) {
          exec_box->OnPressPtr();
          return;
        }
      }
    }

    if (i == box_round_order) {
      if (exec_round_box->Active == 1) {
        if (exec_round_box->OnPressPtr != 0) {
          exec_round_box->OnPressPtr();
          return;
        }
      }
    }

  }
}

static void Process_TP_Up(unsigned int X, unsigned int Y) {
  int i;
  TButton *local_button;
  TButton *exec_button;
  short button_order;
  TButton_Round *local_round_button;
  TButton_Round *exec_round_button;
  short round_button_order;
  TLabel *local_label;
  TLabel *exec_label;
  short label_order;
  TImage *local_image;
  TImage *exec_image;
  short image_order;
  TCircle *local_circle;
  TCircle *exec_circle;
  short circle_order;
  TCircleButton *local_circle_button;
  TCircleButton *exec_circle_button;
  short circle_button_order;
  TBox *local_box;
  TBox *exec_box;
  short box_order;
  TBox_Round *local_round_box;
  TBox_Round *exec_round_box;
  short box_round_order;

  button_order        = -1;
  round_button_order  = -1;
  label_order         = -1;
  image_order         = -1;
  circle_order        = -1;
  circle_button_order = -1;
  box_order           = -1;
  box_round_order     = -1;

  // Buttons
  for ( i = 0 ; i < CurrentScreen->ButtonsCount ; i++ ) {
    local_button = GetButton(i);
    if (local_button->Active == 1) {
      if (IsInsideObject(X, Y, local_button->Left, local_button->Top,
                         local_button->Width, local_button->Height) == 1) {
        button_order = local_button->Order;
        exec_button = local_button;
      }
    }
  }

  // Buttons with Round Edges
  for ( i = 0 ; i < CurrentScreen->Buttons_RoundCount ; i++ ) {
    local_round_button = GetRoundButton(i);
    if (local_round_button->Active == 1) {
      if (IsInsideObject(X, Y, local_round_button->Left, local_round_button->Top,
                         local_round_button->Width, local_round_button->Height) == 1) { +
        round_button_order = local_round_button->Order;
        exec_round_button = local_round_button;
      }
    }
  }

  // Labels
  for ( i = 0 ; i < CurrentScreen->LabelsCount ; i++ ) {
    local_label = GetLabel(i);
    if (local_label->Active == 1) {
      if (IsInsideObject(X, Y, local_label->Left, local_label->Top,
                         local_label->Width, local_label->Height) == 1) { +
        label_order = local_label->Order;
        exec_label = local_label;
      }
    }
  }

  // Images
  for ( i = 0 ; i < CurrentScreen->ImagesCount ; i++ ) {
    local_image = GetImage(i);
    if (local_image->Active == 1) {
      if (IsInsideObject(X, Y, local_image->Left, local_image->Top,
                         local_image->Width, local_image->Height) == 1) { +
        image_order = local_image->Order;
        exec_image = local_image;
      }
    }
  }

  // Circles
  for ( i = 0 ; i < CurrentScreen->CirclesCount ; i++ ) {
    local_circle = GetCircle(i);
    if (local_circle->Active == 1) {
      if (IsInsideObject(X, Y, local_circle->Left, local_circle->Top,
                        (local_circle->Radius * 2), (local_circle->Radius * 2)) == 1) { +
        circle_order = local_circle->Order;
        exec_circle = local_circle;
      }
    }
  }

  // Circle Buttons
  for ( i = 0 ; i < CurrentScreen->CircleButtonsCount ; i++ ) {
    local_circle_button = GetCircleButton(i);
    if (local_circle_button->Active == 1) {
      if (IsInsideObject(X, Y, local_circle_button->Left, local_circle_button->Top,
                        (local_circle_button->Radius * 2), (local_circle_button->Radius * 2)) == 1) { +
        circle_button_order = local_circle_button->Order;
        exec_circle_button = local_circle_button;
      }
    }
  }

  // Boxes
  for ( i = 0 ; i < CurrentScreen->BoxesCount ; i++ ) {
    local_box = GetBox(i);
    if (local_box->Active == 1) {
      if (IsInsideObject(X, Y, local_box->Left, local_box->Top,
                         local_box->Width, local_box->Height) == 1) { +
        box_order = local_box->Order;
        exec_box = local_box;
      }
    }
  }

  // Boxes with Round Edges
  for ( i = 0 ; i < CurrentScreen->Boxes_RoundCount ; i++ ) {
    local_round_box = GetBox_Round(i);
    if (local_round_box->Active == 1) {
      if (IsInsideObject(X, Y, local_round_box->Left, local_round_box->Top,
                         local_round_box->Width, local_round_box->Height) == 1) { +
        box_round_order = local_round_box->Order;
        exec_round_box = local_round_box;
      }
    }
  }

  i = -1;
  if (button_order > i)
    i = button_order;
  if (round_button_order > i)
    i = round_button_order;
  if (label_order > i)
    i = label_order;
  if (image_order > i)
    i = image_order;
  if (circle_order > i)
    i = circle_order;
  if (circle_button_order > i)
    i = circle_button_order;
  if (box_order > i)
    i = box_order;
  if (box_round_order > i)
    i = box_round_order;

  if (i != -1) {
  // Buttons
    if (i == button_order) {
      if (exec_button->Active == 1) {
        if ((exec_button->PressColEnabled == 1) && (PressedObject == (void *)exec_button)) {
          TFT_Set_Brush(exec_button->Transparent, exec_button->Color, exec_button->Gradient, exec_button->Gradient_Orientation, exec_button->Gradient_Start_Color, exec_button->Gradient_End_Color);
          TFT_Set_Pen(exec_button->Pen_Color, exec_button->Pen_Width);
          TFT_Rectangle(exec_button->Left, exec_button->Top, exec_button->Left + exec_button->Width - 1, exec_button->Top + exec_button->Height - 1);
          TFT_Set_Font(exec_button->FontName, exec_button->Font_Color, FO_HORIZONTAL);
          TFT_Write_Text_Return_Pos(exec_button->Caption, exec_button->Left, exec_button->Top);
          TFT_Write_Text(exec_button->Caption, (exec_button->Left + ((exec_button->Width - caption_length) / 2)), (exec_button->Top + ((exec_button->Height - caption_height) / 2)));
        }
        if (exec_button->OnUpPtr != 0)
          exec_button->OnUpPtr();
        if (PressedObject == (void *)exec_button)
          if (exec_button->OnClickPtr != 0)
            exec_button->OnClickPtr();
        PressedObject = 0;
        return;
      }
    }

  // Buttons with Round Edges
    if (i == round_button_order) {
      if (exec_round_button->Active == 1) {
        if ((exec_round_button->PressColEnabled == 1) && (PressedObject == (void *)exec_round_button)) {
          TFT_Set_Brush(exec_round_button->Transparent, exec_round_button->Color, exec_round_button->Gradient, exec_round_button->Gradient_Orientation,
                        exec_round_button->Gradient_Start_Color, exec_round_button->Gradient_End_Color);
          TFT_Set_Pen(exec_round_button->Pen_Color, exec_round_button->Pen_Width);
          if (exec_round_button->Height > exec_round_button->Width)
            TFT_Rectangle_Round_Edges(exec_round_button->Left + 1, exec_round_button->Top + 1,
                                      exec_round_button->Left + exec_round_button->Width - 2,
                                      exec_round_button->Top + exec_round_button->Height - 2, (exec_round_button->Width / 4));
          else if (exec_round_button->Width > exec_round_button->Height)
            TFT_Rectangle_Round_Edges(exec_round_button->Left + 1, exec_round_button->Top + 1,
                                      exec_round_button->Left + exec_round_button->Width - 2,
                                      exec_round_button->Top + exec_round_button->Height - 2, (exec_round_button->Height / 4));
          TFT_Set_Font(exec_round_button->FontName, exec_round_button->Font_Color, FO_HORIZONTAL);
          TFT_Write_Text_Return_Pos(exec_round_button->Caption, exec_round_button->Left, exec_round_button->Top);
          TFT_Write_Text(exec_round_button->Caption, (exec_round_button->Left + ((exec_round_button->Width - caption_length) / 2)),
                        (exec_round_button->Top + ((exec_round_button->Height - caption_height) / 2)));
        }
        if (exec_round_button->OnUpPtr != 0)
          exec_round_button->OnUpPtr();
        if (PressedObject == (void *)exec_round_button)
          if (exec_round_button->OnClickPtr != 0)
            exec_round_button->OnClickPtr();
        PressedObject = 0;
        return;
      }
    }

  // Labels
    if (i == label_order) {
      if (exec_label->Active == 1) {
        if (exec_label->OnUpPtr != 0)
          exec_label->OnUpPtr();
        if (PressedObject == (void *)exec_label)
          if (exec_label->OnClickPtr != 0)
            exec_label->OnClickPtr();
        PressedObject = 0;
        return;
      }
    }

  // Images
    if (i == image_order) {
      if (exec_image->Active == 1) {
        if (exec_image->OnUpPtr != 0)
          exec_image->OnUpPtr();
        if (PressedObject == (void *)exec_image)
          if (exec_image->OnClickPtr != 0)
            exec_image->OnClickPtr();
        PressedObject = 0;
        return;
      }
    }

  // Circles
    if (i == circle_order) {
      if (exec_circle->Active == 1) {
        if ((exec_circle->PressColEnabled == 1) && (PressedObject == (void *)exec_circle)) {
          TFT_Set_Brush(exec_circle->Transparent, exec_circle->Color, exec_circle->Gradient, exec_circle->Gradient_Orientation,
                        exec_circle->Gradient_Start_Color, exec_circle->Gradient_End_Color);
          TFT_Set_Pen(exec_circle->Pen_Color, exec_circle->Pen_Width);
          TFT_Circle(exec_circle->Left + exec_circle->Radius,
                     exec_circle->Top + exec_circle->Radius,
                     exec_circle->Radius);
        }
        if (exec_circle->OnUpPtr != 0)
          exec_circle->OnUpPtr();
        if (PressedObject == (void *)exec_circle)
          if (exec_circle->OnClickPtr != 0)
            exec_circle->OnClickPtr();
        PressedObject = 0;
        return;
      }
    }

  // Circle Buttons
    if (i == circle_button_order) {
      if (exec_circle_button->Active == 1) {
        if ((exec_circle_button->PressColEnabled == 1) && (PressedObject == (void *)exec_circle_button)) {
          TFT_Set_Brush(exec_circle_button->Transparent, exec_circle_button->Color, exec_circle_button->Gradient, exec_circle_button->Gradient_Orientation,
                        exec_circle_button->Gradient_Start_Color, exec_circle_button->Gradient_End_Color);
          TFT_Set_Pen(exec_circle_button->Pen_Color, exec_circle_button->Pen_Width);
            TFT_Circle(exec_circle_button->Left + exec_circle_button->Radius,
                       exec_circle_button->Top + exec_circle_button->Radius,
                       exec_circle_button->Radius);
          TFT_Set_Font(exec_circle_button->FontName, exec_circle_button->Font_Color, FO_HORIZONTAL);
          TFT_Write_Text_Return_Pos(exec_circle_button->Caption, exec_circle_button->Left, exec_circle_button->Top);
          TFT_Write_Text(exec_circle_button->Caption, (exec_circle_button->Left + (((exec_circle_button->Radius*2) - caption_length) / 2)),
                        (exec_circle_button->Top + (((exec_circle_button->Radius*2) - caption_height) / 2)));
        }
        if (exec_circle_button->OnUpPtr != 0)
          exec_circle_button->OnUpPtr();
        if (PressedObject == (void *)exec_circle_button)
          if (exec_circle_button->OnClickPtr != 0)
            exec_circle_button->OnClickPtr();
        PressedObject = 0;
        return;
      }
    }

  // Boxes
    if (i == box_order) {
      if (exec_box->Active == 1) {
        if ((exec_box->PressColEnabled == 1) && (PressedObject == (void *)exec_box)) {
          TFT_Set_Brush(exec_box->Transparent, exec_box->Color, exec_box->Gradient, exec_box->Gradient_Orientation, exec_box->Gradient_Start_Color, exec_box->Gradient_End_Color);
          TFT_Set_Pen(exec_box->Pen_Color, exec_box->Pen_Width);
          TFT_Rectangle(exec_box->Left, exec_box->Top, exec_box->Left + exec_box->Width - 1, exec_box->Top + exec_box->Height - 1);
        }
        if (exec_box->OnUpPtr != 0)
          exec_box->OnUpPtr();
        if (PressedObject == (void *)exec_box)
          if (exec_box->OnClickPtr != 0)
            exec_box->OnClickPtr();
        PressedObject = 0;
        return;
      }
    }

  // Boxes with Round Edges
    if (i == box_round_order) {
      if (exec_round_box->Active == 1) {
        if ((exec_round_box->PressColEnabled == 1) && (PressedObject == (void *)exec_round_box)) {
          TFT_Set_Brush(exec_round_box->Transparent, exec_round_box->Color, exec_round_box->Gradient, exec_round_box->Gradient_Orientation,
                        exec_round_box->Gradient_Start_Color, exec_round_box->Gradient_End_Color);
          TFT_Set_Pen(exec_round_box->Pen_Color, exec_round_box->Pen_Width);
          if (exec_round_box->Height > exec_round_box->Width)
            TFT_Rectangle_Round_Edges(exec_round_box->Left + 1, exec_round_box->Top + 1,
                                      exec_round_box->Left + exec_round_box->Width - 2,
                                      exec_round_box->Top + exec_round_box->Height - 2, (exec_round_box->Width / 4));
          else if (exec_round_box->Width > exec_round_box->Height)
            TFT_Rectangle_Round_Edges(exec_round_box->Left + 1, exec_round_box->Top + 1,
                                      exec_round_box->Left + exec_round_box->Width - 2,
                                      exec_round_box->Top + exec_round_box->Height - 2, (exec_round_box->Height / 4));
        }
        if (exec_round_box->OnUpPtr != 0)
          exec_round_box->OnUpPtr();
        if (PressedObject == (void *)exec_round_box)
          if (exec_round_box->OnClickPtr != 0)
            exec_round_box->OnClickPtr();
        PressedObject = 0;
        return;
      }
    }

  }
  PressedObject = 0;
}

static void Process_TP_Down(unsigned int X, unsigned int Y) {
  int i;
  TButton *local_button;
  TButton *exec_button;
  short button_order;
  TButton_Round *local_round_button;
  TButton_Round *exec_round_button;
  short round_button_order;
  TLabel *local_label;
  TLabel *exec_label;
  short label_order;
  TImage *local_image;
  TImage *exec_image;
  short image_order;
  TCircle *local_circle;
  TCircle *exec_circle;
  short circle_order;
  TCircleButton *local_circle_button;
  TCircleButton *exec_circle_button;
  short circle_button_order;
  TBox *local_box;
  TBox *exec_box;
  short box_order;
  TBox_Round *local_round_box;
  TBox_Round *exec_round_box;
  short box_round_order;

  button_order        = -1;
  round_button_order  = -1;
  label_order         = -1;
  image_order         = -1;
  circle_order        = -1;
  circle_button_order = -1;
  box_order           = -1;
  box_round_order     = -1;

  // Buttons
  for ( i = 0 ; i < CurrentScreen->ButtonsCount ; i++ ) {
    local_button = GetButton(i);
    if (local_button->Active == 1) {
      if (IsInsideObject(X, Y, local_button->Left, local_button->Top,
                         local_button->Width, local_button->Height) == 1) {
        button_order = local_button->Order;
        exec_button = local_button;
      }
    }
  }

  // Buttons with Round Edges
  for ( i = 0 ; i < CurrentScreen->Buttons_RoundCount ; i++ ) {
    local_round_button = GetRoundButton(i);
    if (local_round_button->Active == 1) {
      if (IsInsideObject(X, Y, local_round_button->Left, local_round_button->Top,
                         local_round_button->Width, local_round_button->Height) == 1) { +
        round_button_order = local_round_button->Order;
        exec_round_button = local_round_button;
      }
    }
  }

  // Labels
  for ( i = 0 ; i < CurrentScreen->LabelsCount ; i++ ) {
    local_label = GetLabel(i);
    if (local_label->Active == 1) {
      if (IsInsideObject(X, Y, local_label->Left, local_label->Top,
                         local_label->Width, local_label->Height) == 1) { +
        label_order = local_label->Order;
        exec_label = local_label;
      }
    }
  }

  // Images
  for ( i = 0 ; i < CurrentScreen->ImagesCount ; i++ ) {
    local_image = GetImage(i);
    if (local_image->Active == 1) {
      if (IsInsideObject(X, Y, local_image->Left, local_image->Top,
                         local_image->Width, local_image->Height) == 1) { +
        image_order = local_image->Order;
        exec_image = local_image;
      }
    }
  }

  // Circles
  for ( i = 0 ; i < CurrentScreen->CirclesCount ; i++ ) {
    local_circle = GetCircle(i);
    if (local_circle->Active == 1) {
      if (IsInsideObject(X, Y, local_circle->Left, local_circle->Top,
                        (local_circle->Radius * 2), (local_circle->Radius * 2)) == 1) { +
        circle_order = local_circle->Order;
        exec_circle = local_circle;
      }
    }
  }

  // Circle Buttons
  for ( i = 0 ; i < CurrentScreen->CircleButtonsCount ; i++ ) {
    local_circle_button = GetCircleButton(i);
    if (local_circle_button->Active == 1) {
      if (IsInsideObject(X, Y, local_circle_button->Left, local_circle_button->Top,
                        (local_circle_button->Radius * 2), (local_circle_button->Radius * 2)) == 1) { +
        circle_button_order = local_circle_button->Order;
        exec_circle_button = local_circle_button;
      }
    }
  }

  // Boxes
  for ( i = 0 ; i < CurrentScreen->BoxesCount ; i++ ) {
    local_box = GetBox(i);
    if (local_box->Active == 1) {
      if (IsInsideObject(X, Y, local_box->Left, local_box->Top,
                         local_box->Width, local_box->Height) == 1) { +
        box_order = local_box->Order;
        exec_box = local_box;
      }
    }
  }

  // Boxes with Round Edges
  for ( i = 0 ; i < CurrentScreen->Boxes_RoundCount ; i++ ) {
    local_round_box = GetBox_Round(i);
    if (local_round_box->Active == 1) {
      if (IsInsideObject(X, Y, local_round_box->Left, local_round_box->Top,
                         local_round_box->Width, local_round_box->Height) == 1) { +
        box_round_order = local_round_box->Order;
        exec_round_box = local_round_box;
      }
    }
  }

  i = -1;
  if (button_order > i)
    i = button_order;
  if (round_button_order > i)
    i = round_button_order;
  if (label_order > i)
    i = label_order;
  if (image_order > i)
    i = image_order;
  if (circle_order > i)
    i = circle_order;
  if (circle_button_order > i)
    i = circle_button_order;
  if (box_order > i)
    i = box_order;
  if (box_round_order > i)
    i = box_round_order;
  if (i != -1) {
    if (i == button_order) {
      if (exec_button->Active == 1) {
        if (exec_button->PressColEnabled == 1) {
          TFT_Set_Brush(exec_button->Transparent, exec_button->Press_Color, exec_button->Gradient, exec_button->Gradient_Orientation, exec_button->Gradient_End_Color, exec_button->Gradient_Start_Color);
          TFT_Set_Pen(exec_button->Pen_Color, exec_button->Pen_Width);
          TFT_Rectangle(exec_button->Left, exec_button->Top, exec_button->Left + exec_button->Width - 1, exec_button->Top + exec_button->Height - 1);
          TFT_Set_Font(exec_button->FontName, exec_button->Font_Color, FO_HORIZONTAL);
          TFT_Write_Text_Return_Pos(exec_button->Caption, exec_button->Left, exec_button->Top);
          TFT_Write_Text(exec_button->Caption, (exec_button->Left + ((exec_button->Width - caption_length) / 2)), (exec_button->Top + ((exec_button->Height - caption_height) / 2)));
        }
        PressedObject = (void *)exec_button;
        if (exec_button->OnDownPtr != 0) {
          exec_button->OnDownPtr();
          return;
        }
      }
    }

    if (i == round_button_order) {
      if (exec_round_button->Active == 1) {
        if (exec_round_button->PressColEnabled == 1) {
          TFT_Set_Brush(exec_round_button->Transparent, exec_round_button->Press_Color, exec_round_button->Gradient, exec_round_button->Gradient_Orientation,
                        exec_round_button->Gradient_End_Color, exec_round_button->Gradient_Start_Color);
          TFT_Set_Pen(exec_round_button->Pen_Color, exec_round_button->Pen_Width);
          if (exec_round_button->Height > exec_round_button->Width)
            TFT_Rectangle_Round_Edges(exec_round_button->Left + 1, exec_round_button->Top + 1,
                                      exec_round_button->Left + exec_round_button->Width - 2,
                                      exec_round_button->Top + exec_round_button->Height - 2, (exec_round_button->Width / 4));
          else if (exec_round_button->Width > exec_round_button->Height)
            TFT_Rectangle_Round_Edges(exec_round_button->Left + 1, exec_round_button->Top + 1,
                                      exec_round_button->Left + exec_round_button->Width - 2,
                                      exec_round_button->Top + exec_round_button->Height - 2, (exec_round_button->Height / 4));
          TFT_Set_Font(exec_round_button->FontName, exec_round_button->Font_Color, FO_HORIZONTAL);
          TFT_Write_Text_Return_Pos(exec_round_button->Caption, exec_round_button->Left, exec_round_button->Top);
          TFT_Write_Text(exec_round_button->Caption, (exec_round_button->Left + ((exec_round_button->Width - caption_length) / 2)),
                        (exec_round_button->Top + ((exec_round_button->Height - caption_height) / 2)));
        }
        PressedObject = (void *)exec_round_button;
        if (exec_round_button->OnDownPtr != 0) {
          exec_round_button->OnDownPtr();
          return;
        }
      }
    }

    if (i == label_order) {
      if (exec_label->Active == 1) {
        PressedObject = (void *)exec_label;
        if (exec_label->OnDownPtr != 0) {
          exec_label->OnDownPtr();
          return;
        }
      }
    }

    if (i == image_order) {
      if (exec_image->Active == 1) {
        PressedObject = (void *)exec_image;
        if (exec_image->OnDownPtr != 0) {
          exec_image->OnDownPtr();
          return;
        }
      }
    }

    if (i == circle_order) {
      if (exec_circle->Active == 1) {
        if (exec_circle->PressColEnabled == 1) {
          TFT_Set_Brush(exec_circle->Transparent, exec_circle->Press_Color, exec_circle->Gradient, exec_circle->Gradient_Orientation,
                        exec_circle->Gradient_End_Color, exec_circle->Gradient_Start_Color);
          TFT_Set_Pen(exec_circle->Pen_Color, exec_circle->Pen_Width);
          TFT_Circle(exec_circle->Left + exec_circle->Radius,
                     exec_circle->Top + exec_circle->Radius,
                     exec_circle->Radius);
        }
        PressedObject = (void *)exec_circle;
        if (exec_circle->OnDownPtr != 0) {
          exec_circle->OnDownPtr();
          return;
        }
      }
    }

    if (i == circle_button_order) {
      if (exec_circle_button->Active == 1) {
        if (exec_circle_button->PressColEnabled == 1) {
          TFT_Set_Brush(exec_circle_button->Transparent, exec_circle_button->Press_Color, exec_circle_button->Gradient, exec_circle_button->Gradient_Orientation,
                        exec_circle_button->Gradient_End_Color, exec_circle_button->Gradient_Start_Color);
          TFT_Set_Pen(exec_circle_button->Pen_Color, exec_circle_button->Pen_Width);
            TFT_Circle(exec_circle_button->Left + exec_circle_button->Radius,
                       exec_circle_button->Top + exec_circle_button->Radius,
                       exec_circle_button->Radius);
          TFT_Set_Font(exec_circle_button->FontName, exec_circle_button->Font_Color, FO_HORIZONTAL);
          TFT_Write_Text_Return_Pos(exec_circle_button->Caption, exec_circle_button->Left, exec_circle_button->Top);
          TFT_Write_Text(exec_circle_button->Caption, (exec_circle_button->Left + (((exec_circle_button->Radius*2) - caption_length) / 2)),
                        (exec_circle_button->Top + (((exec_circle_button->Radius*2) - caption_height) / 2)));
        }
        PressedObject = (void *)exec_circle_button;
        if (exec_circle_button->OnDownPtr != 0) {
          exec_circle_button->OnDownPtr();
          return;
        }
      }
    }

    if (i == box_order) {
      if (exec_box->Active == 1) {
        if (exec_box->PressColEnabled == 1) {
          TFT_Set_Brush(exec_box->Transparent, exec_box->Press_Color, exec_box->Gradient, exec_box->Gradient_Orientation, exec_box->Gradient_End_Color, exec_box->Gradient_Start_Color);
          TFT_Set_Pen(exec_box->Pen_Color, exec_box->Pen_Width);
          TFT_Rectangle(exec_box->Left, exec_box->Top, exec_box->Left + exec_box->Width - 1, exec_box->Top + exec_box->Height - 1);
        }
        PressedObject = (void *)exec_box;
        if (exec_box->OnDownPtr != 0) {
          exec_box->OnDownPtr();
          return;
        }
      }
    }

    if (i == box_round_order) {
      if (exec_round_box->Active == 1) {
        if (exec_round_box->PressColEnabled == 1) {
          TFT_Set_Brush(exec_round_box->Transparent, exec_round_box->Press_Color, exec_round_box->Gradient, exec_round_box->Gradient_Orientation,
                        exec_round_box->Gradient_End_Color, exec_round_box->Gradient_Start_Color);
          TFT_Set_Pen(exec_round_box->Pen_Color, exec_round_box->Pen_Width);
          if (exec_round_box->Height > exec_round_box->Width)
            TFT_Rectangle_Round_Edges(exec_round_box->Left + 1, exec_round_box->Top + 1,
                                      exec_round_box->Left + exec_round_box->Width - 2,
                                      exec_round_box->Top + exec_round_box->Height - 2, (exec_round_box->Width / 4));
          else if (exec_round_box->Width > exec_round_box->Height)
            TFT_Rectangle_Round_Edges(exec_round_box->Left + 1, exec_round_box->Top + 1,
                                      exec_round_box->Left + exec_round_box->Width - 2,
                                      exec_round_box->Top + exec_round_box->Height - 2, (exec_round_box->Height / 4));
        }
        PressedObject = (void *)exec_round_box;
        if (exec_round_box->OnDownPtr != 0) {
          exec_round_box->OnDownPtr();
          return;
        }
      }
    }

  }
}

void Check_TP() {
  if (TP_TFT_Press_Detect()) {
    // After a PRESS is detected read X-Y and convert it to Display dimensions space
    if (TP_TFT_Get_Coordinates(&Xcoord, &Ycoord) == 0) {
      Process_TP_Press(Xcoord, Ycoord);
      if (PenDown == 0) {
        PenDown = 1;
        Process_TP_Down(Xcoord, Ycoord);
      }
    }
  }
  else if (PenDown == 1) {
    PenDown = 0;
    Process_TP_Up(Xcoord, Ycoord);
  }
}

void Start_TP() {
  InitializeTouchPanel();

  // You can get calibration constants using touch panel calibration example
  TP_TFT_Set_Calibration_Consts(102, 860, 95, 872);    // Set calibration constants

  InitializeObjects();
  while(1){
    DrawScreen(&Screen1);
    Delay_ms(2000);
    DrawScreen(&Screen2);
    Delay_ms(2000);
    DrawScreen(&Screen3);
    Delay_ms(2000);
  }
}