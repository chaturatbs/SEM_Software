/* Project name:
     TFT_Demo
 * Copyright:
     (c) Mikroelektronika, 2010.
 * Revision History:
     20101227(TL):
       - initial release;
 * Description:
     This is a simple TFT display demo example.
 * Test configuration:
     MCU:             PIC24FJ256GB110
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39897c.pdf
     Dev.Board:       LV24-33 v6
                      http://www.mikroe.com/eng/products/view/430/lv-24-33-v6-development-system/
     Oscillator:      HS-PLL 4x, 08.0000 MHz
     Ext. Modules:    ac:Voltage_trans
                      http://www.mikroe.com/eng/products/view/182/5v-3-3v-voltage-translator-board/
                      ac:SmartADAPT
                      http://www.mikroe.com/eng/products/view/158/smartadapt2-board/
                      ac:TFT_PROTO
                      http://www.mikroe.com/eng/products/view/474/tft-proto-board/
     SW:              mikroC PRO for dsPIC30/33 and PIC24
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic30-33-and-pic24/

*/

#include "TFT_demo_objects.h"

void main() {

  Start_TP();

  while (1) {
    Check_TP();

  }

}